'''
Given a string, reverse the given string.

Input Format

Input contains a String - S.

Constraints

1 <= len(s) <= 100

Output Format

Print the reversed string.

Sample Input 0

fdsrd
Sample Output 0

drsdf
Explanation 0

Self Explanatory
'''

s=str(input())
print(s[::-1])
